<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>

<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">الرئيسية</a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.stors.create')); ?>">أضافة مخزون جديد</a>
                                </li>
                                <li class="breadcrumb-item active">كل المخزون
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- Basic form layout section start -->
                <section id="basic-form-layouts">
                    <div class="row match-height">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title" id="basic-layout-form"> أضافة مخزون  </h4>
                                    <a class="heading-elements-toggle"><i
                                            class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <?php echo $__env->make('admin.includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('admin.includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="card-content collapse show">
                                    <div class="card-body">

                                        <div class="card-body" id="tab_logic">

                                        <form class="form"  action="<?php echo e(route('admin.stors.store')); ?>"
                                              method="POST"
                                              enctype="multipart/form-data" >
                                            <?php echo csrf_field(); ?>
                                            <div class="form-body" id="tbody">

                                                <h4 class="form-section"><i class="ft-home"></i>بيانات المخزون  </h4>
                                                <div class="row "id="tr" >

                                                    <div class="col-lg-4">
                                                        <div class="form-group" >

                                                            <label for="projectinput1"> أسم المنتج </label>
                                                            <input type="text" name='product_name'  placeholder='Enter Product Name' class="form-control"/>
                                                            <?php $__errorArgs = ["product_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <div class="form-group" >
                                                            <label for="projectinput1"> الوصف</label>

                                                            <input type="text" name='description'  placeholder='Enter Product' class="form-control"/>
                                                            <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-4">
                                                        <div class="form-group" >
                                                            <label for="projectinput1"> العدد  </label>

                                                            <input type="number" name='count_proud' placeholder='Enter Qty' class="form-control qty" step="0" min="0"/>
                                                            <?php $__errorArgs = ["count_proud"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                   <div class="col-lg-4">
                                                        <div class="form-group " >
                                                            <label for="projectinput1"> سعر الشراء  </label>

                                                            <input type="number" name='buy_price' placeholder='Enter Unit Price' class="form-control price" step="0.00" min="0"/>
                                                            <?php $__errorArgs = ["buy_price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                               <div class="col-lg-4">
                                                        <div class="form-group " >
                                                            <label for="projectinput1"> سعر البيع  </label>

                                                            <input type="number" name='selling_price' placeholder='0.00' class="form-control" />
                                                            <?php $__errorArgs = ["selling_price"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                          <div class="col-lg-4">
                                                        <div class="form-group ">
                                                            <label for="projectinput1">اجمالي السعر  </label>
                                                            <input type="number" name='total_price' placeholder='0.00' class="form-control total" readonly/>


                                                            <?php $__errorArgs = ["total_pric"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> هذا الحقل مطلوب</span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>


                                            </div>

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group mt-1">
                                                            <input type="checkbox" value="1"
                                                                   name="active"
                                                                   id="switcheryColor4"
                                                                   class="switchery" data-color="success"
                                                                   checked/>
                                                            <label for="switcheryColor4"
                                                                   class="card-title ml-1">الحالة   </label>

                                                            <?php $__errorArgs = ["active"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"> </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-actions">
                                                <button type="button" class="btn btn-warning mr-1"
                                                        onclick="history.back();">
                                                    <i class="ft-x"></i> تراجع
                                                </button>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="la la-check-square-o"></i> حفظ
                                                </button>
                                            </div>
                                        </form>




                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- // Basic form layout section end -->
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            var i=1;
            // $("#add_row").click(function(){b=i-1;
            //     $('#addr'+i).html($('#addr'+b).html()).find('td:first-child').html(i+1);
            //     $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
            //     i++;
            // });
            // $("#delete_row").click(function(){
            //     if(i>1){
            //         $("#addr"+(i-1)).html('');
            //         i--;
            //     }
            //     calc();
            // });

            $('#tab_logic #tbody').on('keyup change',function(){
                calc();
            });
            // $('#tax').on('keyup change',function(){
            //     calc_total();
            // });


        });

        function calc()
        {
            $('#tab_logic #tbody #tr').each(function(i, element) {
                var html = $(this).html();
                if(html!='')
                {
                    var qty = $(this).find('.qty').val();
                    var price = $(this).find('.price').val();
                    $(this).find('.total').val(qty*price);

                    calc_total();
                }
            });
        }

        // function calc_total()
        // {
        //     total=0;
        //     $('.total').each(function() {
        //         total += parseInt($(this).val());
        //     });
        //     $('#sub_total').val(total.toFixed(2));
        //     tax_sum=total/100*$('#tax').val();
        //     $('#tax_amount').val(tax_sum.toFixed(2));
        //     $('#total_amount').val((tax_sum+total).toFixed(2));
        // }


    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\estraha\estahasystem\resources\views/admin/pages/allstors/create.blade.php ENDPATH**/ ?>
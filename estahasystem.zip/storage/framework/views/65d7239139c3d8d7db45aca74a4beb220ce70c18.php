<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>

</script>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title"> الاقسام الرئيسية </h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">الرئيسية</a>
                                </li>
                                </li>
                                <li class="breadcrumb-item active">كل التقارير
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- DOM - jQuery events table -->
                <section id="dom">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">التقارير  </h4>
                                    <a class="heading-elements-toggle"><i
                                            class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <?php echo $__env->make('admin.includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('admin.includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="card-content collapse show">
                                    <div class="card-body card-dashboard">
                                    </div>

                                    <table id="sum_table"

                                    class="table display nowrap table-striped table-bordered scroll-horizontal" >

                                            <thead class="">
                                            <tr>
                                                <th> العملية  </th>
                                                <th> القيمة  </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                    <tr>
                                                        <th>  رصيد الخزنه  </th>
                                                        <td><?php echo $balance; ?></td>
                                                    </tr> <tr>
                                                        <th> أجمالي الايرادات  </th>
                                                        <td><?php echo $expenses; ?></td>
                                                    </tr>
                                             <tr>
                                                 <th>  أجمالي المصروفات </th>
                                                        <td><?php echo $covenant; ?></td>
                                                    </tr>
                                             <tr>
                                                 <th>أجمالي العهد</th>
                                                        <td><?php echo $covenant; ?></td>
                                                    </tr>
                                             <tr>
                                                 <th> أجمالي قيمة المخزون  </th>
                                                        <td><?php echo $total_price; ?></td>
                                                    </tr>
                                             <tr>
                                                        <th> اجمالي عدد المخزون </th>
                                                        <td><?php echo $counts; ?></td>
                                                    </tr>
                                             <tr>
                                                        <th> أجمالي سعر المخزون</th>
                                                        <td><?php echo $buy_price; ?></td>
                                                    </tr>
                                             <tr>
                                                        <th> أجمالي ارباح وخسائر </th>
                                                        <td><?php echo $profitLoss; ?></td>
                                                    </tr>
                                             <tr>
                                                        <th> الرصيد الحالي </th>
                                                        <td><?php echo $current_balance; ?></td>
                                                    </tr>



                                            </tbody>
                                        <tfoot>
                                        <tr>
                                            <td>0</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>


                                        </tr>

                                        </tfoot>

                                        </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
            </div>
        </div>
    </div>
























<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\estraha\estahasystem\resources\views/admin/pages/repotss/index.blade.php ENDPATH**/ ?>
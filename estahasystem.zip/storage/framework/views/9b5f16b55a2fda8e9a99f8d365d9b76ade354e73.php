<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>

</script>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title"> الاقسام الرئيسية </h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">الرئيسية</a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.stors.create')); ?>">أضافة مخزن جديد</a>
                                </li>
                                <li class="breadcrumb-item active">كل المخازن
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- DOM - jQuery events table -->
                <section id="dom">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">المخازن  </h4>
                                    <a class="heading-elements-toggle"><i
                                            class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <?php echo $__env->make('admin.includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('admin.includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="card-content collapse show">
                                    <div class="card-body card-dashboard">
                                    </div>
                                    <table   class="table table-bordered" style="width:95%;">

                                    <thead>

<tr>
<th>الكل</th>
    <td style="color: red">اجمالي عدد المخزون الفعلي<?php echo e($counts); ?></td>

    <td style="color: red">أجمالي قيمة المخزون:<?php echo $total_price; ?></td>
                                            <td style="color: red">أجمالي سعر المخزون: <?php echo e($buy_price); ?></td>

</tr>

<tr>
    <th>الفعلي</th>
    <td style="color: red">اجمالي عدد المخزون الفعلي<?php echo e($counactiv); ?></td>

    <td style="color: red">أجمالي قيمة المخزون:<?php echo $totalpriactiv; ?></td>

                                            <td style="color: red">أجمالي سعر المخزون: <?php echo e($pricactiv); ?></td>

</tr>

                                        </thead><tbody></tbody>



                                    </table>
                                    <table id="sum_table"

                                    class="table display nowrap table-striped table-bordered scroll-horizontal" >

                                            <thead class="">
                                            <tr>
                                                <th> م  </th>
                                                <th> أسم المنتج  </th>
                                                <th>  الوصف </th>
                                                <th>العدد</th>

                                                <th> سعر الشراء  </th>
                                                <th> أجمالي السعر  </th>
                                                <th>  سعر البيع  </th>
                                                <th>  الحاله   </th>
                                                <th>  تاريخ البيع  </th>
                                                <th>  اليوم البيع  </th>


                                                <th>الإجراءات</th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            <?php if(isset($allstors)): ?>

                                                <?php $__currentLoopData = $allstors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($stors -> id); ?></td>
                                                        <td><?php echo e($stors -> product_name); ?></td>
                                                        <td><?php echo e($stors -> description); ?></td>
                                                        <td><?php echo e($stors -> count_proud); ?></td>
                                                        <td><?php echo e($stors -> buy_price); ?></td>
                                                        <td><?php echo e($stors -> total_price); ?></td>
                                                        <td><?php echo e($stors -> selling_price); ?></td>
                                                        <td><?php echo e($stors -> getActive()); ?></td>
                                                        <td><?php echo e($stors->created_at->format('l')); ?></td>
                                                        <td><?php echo e($stors->created_at->format('y/m/d')); ?></td>


                                                        <td>
                                                            <div class="btn-group" role="group"
                                                                 aria-label="Basic example">
                                                                <a href="<?php echo e(route('admin.stors.edit',$stors -> id)); ?>"
                                                                   class="btn btn-outline-primary btn-min-width box-shadow-3 mr-1 mb-1">تعديل</a>


                                                                <a href="<?php echo e(route('admin.stors.delete',$stors -> id)); ?>"
                                                                   class="btn btn-outline-danger btn-min-width box-shadow-3 mr-1 mb-1">حذف</a>

                                                                <a href="<?php echo e(route('admin.stors.status',$stors -> id)); ?>"
                                                                   class="btn btn-outline-warning btn-min-width box-shadow-3 mr-1 mb-1">
                                                                    <?php if($stors -> active == 0): ?>
                                                                        تفعيل
                                                                    <?php else: ?>
                                                                        الغاء تفعيل
                                                                    <?php endif; ?>
                                                                </a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>


                                            </tbody>
                                        <tfoot>
                                        <tr>
                                            <td>0</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>


                                        </tr>

                                        </tfoot>

                                        </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
            </div>
        </div>
    </div>
























<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\estraha\estahasystem\resources\views/admin/pages/allstors/index.blade.php ENDPATH**/ ?>